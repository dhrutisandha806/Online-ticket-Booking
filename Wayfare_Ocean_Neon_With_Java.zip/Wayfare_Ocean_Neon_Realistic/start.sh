#!/bin/sh
cd "$(dirname "$0")" || exit 1
javac WayfareServer.java || exit 1
exec java WayfareServer
