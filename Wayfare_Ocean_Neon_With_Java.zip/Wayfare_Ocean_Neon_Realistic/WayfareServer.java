import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

/** Java backend for the Wayfare college demonstration website. */
public class WayfareServer {
    private static final int PORT = 8080;
    private static final Path WEB_ROOT = Path.of(".").toAbsolutePath().normalize();
    private static final Map<String, Set<String>> BOOKED_SEATS = new ConcurrentHashMap<>();
    private static final Object BOOKING_LOCK = new Object();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/bookings", WayfareServer::createBooking);
        server.createContext("/", WayfareServer::serveWebsite);
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("Wayfare Java server running at http://localhost:" + PORT);
        System.out.println("Press Ctrl+C to stop the server.");
    }

    private static void serveWebsite(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            send(exchange, 405, "text/plain; charset=UTF-8", "Method not allowed");
            return;
        }
        String path = exchange.getRequestURI().getPath();
        if ("/".equals(path)) path = "/index.html";
        Path file = WEB_ROOT.resolve(path.substring(1)).normalize();
        if (!file.startsWith(WEB_ROOT) || !Files.isRegularFile(file)) {
            send(exchange, 404, "text/plain; charset=UTF-8", "File not found");
            return;
        }
        String type = file.toString().endsWith(".html") ? "text/html; charset=UTF-8" : "text/plain; charset=UTF-8";
        send(exchange, 200, type, Files.readString(file, StandardCharsets.UTF_8));
    }

    private static void createBooking(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            send(exchange, 405, "application/json; charset=UTF-8", "{\"error\":\"Use POST to create a booking.\"}");
            return;
        }
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> form = parseForm(body);
        String passenger = form.getOrDefault("passengerName", "").trim();
        String phone = form.getOrDefault("phone", "").trim();
        String date = form.getOrDefault("travelDate", "").trim();
        String tripId = form.getOrDefault("tripId", "").trim();
        String route = form.getOrDefault("route", "").trim();
        String seatsText = form.getOrDefault("seats", "").trim();
        if (passenger.isEmpty() || phone.length() < 8 || date.isEmpty() || tripId.isEmpty() || route.isEmpty() || seatsText.isEmpty()) {
            send(exchange, 400, "application/json; charset=UTF-8", "{\"error\":\"Please provide valid passenger, route, date and seat details.\"}");
            return;
        }
        Set<String> requested = new HashSet<>(Arrays.asList(seatsText.split(",")));
        if (requested.size() != seatsText.split(",").length) {
            send(exchange, 400, "application/json; charset=UTF-8", "{\"error\":\"Duplicate seat selected.\"}");
            return;
        }
        String key = date + "|" + form.getOrDefault("mode", "") + "|" + tripId;
        synchronized (BOOKING_LOCK) {
            Set<String> occupied = BOOKED_SEATS.computeIfAbsent(key, k -> ConcurrentHashMap.newKeySet());
            for (String seat : requested) {
                if (occupied.contains(seat.trim())) {
                    send(exchange, 409, "application/json; charset=UTF-8", "{\"error\":\"Seat " + jsonEscape(seat.trim()) + " has already been booked on the Java server. Please select another seat.\"}");
                    return;
                }
            }
            occupied.addAll(requested);
        }
        String bookingId = "WF" + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase();
        System.out.printf("BOOKING %s | %s | %s | %s | seats=%s | amount=%s%n", bookingId, passenger, route, date, seatsText, form.getOrDefault("amount", "0"));
        String json = "{\"bookingId\":\"" + bookingId + "\",\"status\":\"CONFIRMED\",\"message\":\"Demo booking stored by Java backend.\"}";
        send(exchange, 201, "application/json; charset=UTF-8", json);
    }

    private static Map<String, String> parseForm(String body) {
        Map<String, String> result = new HashMap<>();
        for (String pair : body.split("&")) {
            String[] parts = pair.split("=", 2);
            String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
            String value = parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "";
            result.put(key, value);
        }
        return result;
    }

    private static String jsonEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static void send(HttpExchange exchange, int status, String contentType, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(status, bytes.length);
        try (var output = exchange.getResponseBody()) { output.write(bytes); }
    }
}
