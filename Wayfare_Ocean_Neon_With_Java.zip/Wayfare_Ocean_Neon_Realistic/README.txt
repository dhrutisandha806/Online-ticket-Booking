WAYFARE — OCEAN NEON (REALISTIC EDITION) + JAVA BACKEND

WHAT'S INCLUDED
- index.html: original website interface and Ocean Neon design (visual styling kept intact)
- WayfareServer.java: Java HTTP server, booking endpoint, synchronized seat checks, and booking ID generation
- start.bat: compile and start the Java backend on Windows
- start.sh: compile and start the Java backend on macOS/Linux

RUN ON WINDOWS
1. Extract the ZIP file to a folder.
2. Make sure a JDK is installed (JDK 17 or later recommended).
3. Double-click start.bat.
4. Open http://localhost:8080 in Chrome or Edge.
5. Search a route, choose seats, enter passenger details, and confirm.
6. Keep the server window open while using the website. Press Ctrl+C there to stop it.

RUN ON MACOS / LINUX
1. Open Terminal in the extracted folder.
2. Run: chmod +x start.sh
3. Run: ./start.sh
4. Open http://localhost:8080 in your browser.

JAVA CONCEPTS DEMONSTRATED
- Classes and methods
- HTTP request handling
- Multithreaded request handling using a thread pool
- Synchronization with a shared booking lock
- Collections for tracking booked seats
- Validation and exception-safe HTTP responses

IMPORTANT
This is an educational demonstration, not a production ticketing system. Routes, prices and availability displayed by the interface are simulated. The Java server accepts demo bookings in memory; bookings are cleared when the server restarts. It does not process real payments or issue real tickets. For the Java booking API to work, open the website at http://localhost:8080, not by double-clicking index.html.
