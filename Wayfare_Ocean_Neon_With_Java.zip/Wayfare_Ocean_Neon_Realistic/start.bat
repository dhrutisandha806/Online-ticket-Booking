@echo off
cd /d "%~dp0"
echo Compiling Wayfare Java backend...
javac WayfareServer.java
if errorlevel 1 (
  echo.
  echo Compilation failed. Install a JDK 17 or later and try again.
  pause
  exit /b 1
)
echo Starting Wayfare at http://localhost:8080
echo Keep this window open while using the website. Press Ctrl+C to stop.
java WayfareServer
pause
